#' Menghitung luas lingkaran
#'
#' @param radius Radius lingkaran
#' @return Luas lingkaran
#' @export
area_circle <- function(radius) {
  if (radius <= 0) stop("Radius harus positif")
  pi * radius^2
}

#' Menghitung luas persegi panjang
#'
#' @param length Panjang persegi panjang
#' @param width Lebar persegi panjang
#' @return Luas persegi panjang
#' @export
area_rectangle <- function(length, width) {
  if (length <= 0 || width <= 0) stop("Panjang dan lebar harus positif")
  length * width
}

#' Menghitung luas segitiga
#'
#' @param base Panjang alas segitiga
#' @param height Tinggi segitiga
#' @return Luas segitiga
#' @export
area_triangle <- function(base, height) {
  if (base <= 0 || height <= 0) stop("Panjang alas dan tinggi harus positif")
  0.5 * base * height
}
