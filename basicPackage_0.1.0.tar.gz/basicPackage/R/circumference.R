#' @importFrom testthat expect_equal expect_error
#' @title Menghitung keliling lingkaran
#' @description Menghitung keliling lingkaran berdasarkan radius yang diberikan.
#' @param radius Radius lingkaran
#' @return Keliling lingkaran
#' @export
circumference_circle <- function(radius) {
  if (radius <= 0) stop("Radius harus positif")
  2 * pi * radius
}

#' @title Menghitung keliling persegi panjang
#' @description Menghitung keliling persegi panjang berdasarkan panjang dan lebar yang diberikan.
#' @param length Panjang persegi panjang
#' @param width Lebar persegi panjang
#' @return Keliling persegi panjang
#' @export
circumference_rectangle <- function(length, width) {
  if (length <= 0 || width <= 0) stop("Panjang dan lebar harus positif")
  2 * (length + width)
}

#' @title Menghitung keliling segitiga
#' @description Menghitung keliling segitiga berdasarkan panjang tiga sisi yang diberikan.
#' @param side1 Panjang sisi pertama segitiga
#' @param side2 Panjang sisi kedua segitiga
#' @param side3 Panjang sisi ketiga segitiga
#' @return Keliling segitiga
#' @export
circumference_triangle <- function(side1, side2, side3) {
  if (side1 <= 0 || side2 <= 0 || side3 <= 0) stop("Semua sisi harus positif")
  side1 + side2 + side3
}
