#' Unit tests for basicPackage
#'
#' @importFrom testthat expect_equal expect_error
library(testthat)
library(basicPackage)

test_that("circumference_circle works correctly", {
  expect_equal(circumference_circle(1), 2 * pi)
  expect_error(circumference_circle(-1))
})

test_that("circumference_rectangle works correctly", {
  expect_equal(circumference_rectangle(2, 3), 2 * (2 + 3))
  expect_error(circumference_rectangle(-2, 3))
})

test_that("circumference_triangle works correctly", {
  expect_equal(circumference_triangle(3, 4, 5), 3 + 4 + 5)
  expect_error(circumference_triangle(3, 4, -5))
})

test_that("area_circle works correctly", {
  expect_equal(area_circle(1), pi)
  expect_error(area_circle(-1))
})

test_that("area_rectangle works correctly", {
  expect_equal(area_rectangle(2, 3), 2 * 3)
  expect_error(area_rectangle(-2, 3))
})

test_that("area_triangle works correctly", {
  expect_equal(area_triangle(2, 3), 0.5 * 2 * 3)
  expect_error(area_triangle(2, -3))
})
